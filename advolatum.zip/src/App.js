import React, {useState} from 'react';
import {Route, Routes} from "react-router-dom";
import Header from "./components/Header/Header.jsx";
import Footer from "./components/Footer/Footer";

import Home from "./pages/Home";
import About from "./pages/About";
import Basket from "./pages/Basket";
import Catalog from "./pages/Catalog";
import Colection from "./pages/Colection";
import Contacts from "./pages/Contacts";
import Catalogpage from "./pages/Catalogpage";
import Geoposition from "./components/Geoposition/Geoposition";
import Catalogpagetwo from "./pages/Catalogpagetwo";
import Catalogpagethree from "./pages/Catalogpagethree";
import Catalogpagefour from "./pages/Catalogpagefour";



const App = () => {
    return (
        <div className="App">
            <Header/>
                <Routes>
                    <Route path="/" element={<Home/>}/>
                    <Route path="/Contacts" element={<Contacts/>}/>
                    <Route path="/Colection" element={<Colection/>}/>
                    <Route path="/Catalog" element={<Catalog/>}/>
                    <Route path="/Basket" element={<Basket/>}/>
                    <Route path="/About" element={<About/>}/>
                    <Route path="/Catalogpage" element={<Catalogpage/>}/>/
                    <Route path="/Catalogpagetwo" element={<Catalogpagetwo/>}/>
                    <Route path="/Catalogpagethree" element={<Catalogpagethree/>}/>
                    <Route path="/Catalogpagefour" element={<Catalogpagefour/>}/>
                </Routes>
            <Footer/>
        </div>
    );
};

export default App;