import React from 'react';
import season from '../../images/на этот сезон (1).png';
import karusel from '../../images/season.svg'
import logos from "../../images/logos.svg";

import { Link } from "react-router-dom";

const Season = () => {
    return (
        <div className="container__adv">
            <div className="season__box">
                <img src={season} alt=""/>
                <div className="season__header">
                    <div className="ftr__header">
                        <h3 className="ftr__title">на этот сезон</h3>
                    </div>
                </div>
                <div className="season__slider__extwrap">
                    <div id="banner0" className="season__slider__wrap  slick-initialized slick-slider slick-dotted">
                        <button className="slick-prev slick-arrow" aria-label="Previous" type="button">
                            Previous
                        </button>
                        <div className="slick-list draggable">
                            <div className="slick-track">
                                <div className="slick-slide slick-cloned" data-slick-index="-1" aria-hidden="true"
                                     tabIndex="-1">
                                    <div className="season__item">
                                        <img src={karusel} alt="" className="season__img"/>
                                        <div className="season__text">
                                            <p className="season__title">Питерский андеграунд в новой реальности</p>
                                            <button className="btn">
                                                <Link className="btn__link" to="/Catalog">
                                                    КАТАЛОГ
                                                </Link>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Season;