import React from 'react';
import tglogo from '../../images/telegram.logo.svg'
import vklogo from '../../images/vk.logo.svg'
import instalogo from '../../images/instagram.svg'


const Footer = () => {
    return (
    <div className="container__adv">
        <div className="footer__box">
            <div className="footer__left__wrap">
                <div className="footer__left">
                    <a href="#">политика
                        конфиденциальности</a>
                    <a href="#">согласие на обработку
                        персональных данных</a>
                </div>
                <div className="footer__mid">
                    <div className="header__logo">
                        <a href=""><img src="https://advolatum.ru/catalog/view/theme/adv__theme/image/adv__theme/logo__ftr.svg" title="" alt=""/></a>
                    </div>
                    <p>2022 GruboGovorya</p>
                </div>
            </div>
            <div className="footer__right">
                <div className="header__soc">
                    <div className="hs__icon1"><a href="https://t.me/advolatumshop"><img src={tglogo} alt=""/></a></div>
                    <div className="hs__icon2"><a href="https://vk.com/advolatum.shop"><img src={vklogo} alt=""/></a></div>
                    <div className="hs__icon3"><a href="#"><img src={instalogo} alt=""/></a></div>
                </div>
            </div>
        </div>
    </div>
    );
};

export default Footer;