import React from 'react';
import logo from '../../images/logo.png'
import tglogo from '../../images/telegram.logo.svg'
import vklogo from '../../images/vk.logo.svg'
import instalogo from '../../images/instagram.svg'
import {Link} from "react-router-dom";

const Header = () => {
		return (
			<>
			<header className="header">
				<div className="container_adv">
					<div className="header__box">
						<div className="header__top">
							<div className="header__items">

								<div className="header__logo">
									<a href="#"><img className="#" src={logo} title="Advolatum" alt="Advolatum" /></a>
								</div>
								<div className="header__menu">
									<li><Link to="/" href="#" className="active">ГЛАВНАЯ</Link></li>
									<li><Link to="/Colection" href="#">КОЛЛЕКЦИИ</Link></li>
									<li><Link to="/About" href="#">О НАС</Link></li>
									<li><a  onclick="window.scrollTo({ top: [расчетная прокрутка], behavior: 'smooth'});">КОНТАКТЫ</a></li>
									<li><Link to="/Basket" href="#">КОРЗИНА</Link></li>
								</div>
							</div>
                            <div className="header__soc">
                                <div className="hs__icon1"><a href="https://t.me/advolatumshop"><img src={tglogo} alt=""/></a></div>
                                <div className="hs__icon2"><a href="https://vk.com/advolatum.shop"><img src={vklogo} alt=""/></a></div>
                                <div className="hs__icon3"><a href="#"><img src={instalogo} alt=""/></a></div>
                            </div>
						</div>
						<div className="header__bottom">
							<div className="header__categs">
								<Link to="/Catalog">ДЕВУШКАМ</Link>
								<Link to="/Catalog">МУЖЧИНАМ</Link>
								<Link to="/Catalog">УНИСЕКС</Link>
							</div>
						</div>
					</div>
				</div>
			</header>
			</>
		);
};

export default Header;