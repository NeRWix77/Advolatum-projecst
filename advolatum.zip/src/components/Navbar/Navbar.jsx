import React from 'react';
import bgimage1 from '../../images/Component 2.svg'
import bgimage2 from '../../images/Component 1.png'
import bgimage3 from '../../images/Одежда для каждого (1).svg'
import logos from '../../images/logos.svg'

import {Link} from "react-router-dom";

const Navbar = () => {
    return (
        <div className="common-home">
            <div id="content">
                <div className="container_adv">
                    <div className="home__top">
                        <div className="mid__img">
                            <img className="bg" src={bgimage3} alt=""/>
                            <img className="img" src={bgimage1} alt=""/>
                            <img className="img_m" src={bgimage2} alt=""/>
                        </div>
                    </div>
                <div className="ht__mid">
                    <h3>НА КАЖДЫЙ ДЕНЬ</h3>
                </div>
                    <div className="ht__btn">
                       <button className="btn">
                           <Link className="btn__link" to="/Catalog">
                               КАТАЛОГ
                           </Link>
                       </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Navbar;