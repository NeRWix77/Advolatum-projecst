import React from 'react';
import Contacts from '../../images/контакты.png'
import Place from '../../images/Rectangle.png'
const Geoposition = () => {
    return (
        <div className="container__adv mapless">
            <div id="map__box1" className="map__box">
                <img className="map__img" src={Contacts} alt=""/>
                <div className="map__header">
                    <div className="ftr__header">
                        <h3>Мы всегда на связи</h3>
                    </div>
                </div>
                <div className="map__content">
                    <div className="map__left">
                    </div>
                    <img src={Place} alt=""/>
                    <div class="map__right"><span>+7(995)500-04-01</span>&nbsp;<span>advolatum@bk.ru</span>
                        <div className="footer__right">
                        <div className="header__soc">
                            <div className="hs__icon1"><a href="#"></a></div>
                            <div className="hs__icon2"><a href="#"></a></div>
                            <div className="hs__icon3"><a href="#"></a></div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Geoposition;