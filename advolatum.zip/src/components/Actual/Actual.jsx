import React, {useEffect, useState} from 'react';
import axios from "axios";
import bgactual from  '../../images/На этот сезон ДУБЛЬ.png'
import card1 from '../../images/cardone.jpeg'
import card2 from '../../images/cardtwo.jpeg'
import card3 from '../../images/cardthree.jpeg'
import card4 from '../../images/cardfour.jpeg'
import modalimg1 from  '../../images/cardone.jpeg'
import modalimg2 from  '../../images/cardtwo.jpeg'
import modalimg3 from  '../../images/cardthree.jpeg'
import modalimg4 from  '../../images/cardfour.jpeg'
import scale from '../../images/Frame 27.png'
import colors from "../../images/Цвета.png"
import Modal from "../Modal/Modal";
import {Link} from "react-router-dom";
const Actual = () => {
    const [modalActive1, setModalActive1] = useState(false);
    const [modalActive2, setModalActive2] = useState(false);
    const [modalActive3, setModalActive3] = useState(false);
    const [modalActive4, setModalActive4] = useState(false);

    const [actual, setActual] = useState([])

    useEffect(() => {
        axios('http://localhost:8000/products')
            .then(({ data }) => setActual(data))
    }, [actual])

    return (
        <div className="container__adv">
            <div className="ftr__header featured__top">
                <img src={bgactual} alt=""/>
                <h2 className="actual__title">Актуальное</h2>
            </div>
            <div className="featured__box">
                <div className="ftr__itemss_cards">
                    {actual }
                    <div onClick={() => setModalActive1(true)} className="product-layout ftr__item__box" style={{ backgroundImage:`url(${card1})`,backgroundRepeat:"no-repeat", backgroundSize:"contain"}}>
                        <div className="ftr__image hov__point">
                            <div className="ftr__text__hov">
                                <p className="thov__top">Куртка Antiquus</p>
                                <p className="thov__bottom">Потертая стилизованная джинса на плотной зимней подкладке.
                                    Все размеры. Высокий ворот, стильный ярки..</p>
                            </div>
                            <div  className="ftr__btn__hov">
                                <div className="cart__btn">
                                    <span>Подробнее...</span>
                                </div>
                            </div>
                        </div>
                        <div className="ftr__bottom">
                            <div className="ftr__name">
                                <Link to="./" onClick={() => setModalActive1(true)}>Куртка Antiquus</Link>
                            </div>
                            <div className="ftr__lower">
                                <span>
                        8000₽
                      </span>
                                <div className="cart__btn" >
                                    <span>В корзину</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div onClick={() => setModalActive2(true)} className="product-layout ftr__item__box" style={{ backgroundImage:`url(${card2})`,backgroundRepeat:"no-repeat",backgroundSize:"contain"}}>
                        <div className="ftr__image hov__point"
                        >
                            <div className="ftr__text__hov">
                                <p className="thov__top">Штормовка Contra</p>
                                <p className="thov__bottom">Урбанистский стиль с солнечными нотами.&nbsp;..</p>
                            </div>
                            <div className="ftr__btn__hov">
                                <div className="cart__btn">
                                    <span>Подробнее...</span>
                                </div>
                            </div>
                        </div>
                        <div className="ftr__bottom">
                            <div className="ftr__name">
                                <Link to="./" onClick={() => setModalActive2(true)}>Штормовка Contra</Link>
                            </div>
                            <div className="ftr__lower">
          <span>
                        6000₽
                      </span>
                                <div className="cart__btn" >
                                    <span>В корзину</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div onClick={() => setModalActive3(true)} className="product-layout ftr__item__box" style={{ backgroundImage:`url(${card4})`,backgroundRepeat:"no-repeat",backgroundSize:"contain"}}>
                        <div className="ftr__image hov__point"
                        >
                            <div className="ftr__text__hov">
                                <p className="thov__top">Снепбэк Бошка</p>
                                <p className="thov__bottom">Дерзость и молодость. Прямой козырек, сочный принт. Летом
                                    защищает от солнца, зимой от снега...</p>
                            </div>
                            <div className="ftr__btn__hov">
                                <div className="cart__btn">
                                    <span>Подробнее...</span>
                                </div>
                            </div>
                        </div>
                        <div className="ftr__bottom">
                            <div className="ftr__name">
                                <Link to="./" onClick={() => setModalActive3(true)}>
                                    Снэбпек Бошка
                                </Link>
                            </div>
                            <div className="ftr__lower">
          <span>
                        2600₽
                      </span>
                                <div className="cart__btn" >
                                    <span>В корзину</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div onClick={() => setModalActive4(true)} className="product-layout ftr__item__box" style={{ backgroundImage:`url(${card3})`,backgroundRepeat:"no-repeat",backgroundSize:"contain"}}>
                        <div className="ftr__image hov__point">
                            <div className="ftr__text__hov">
                                <p className="thov__top">Штормовка Contra</p>
                                <p className="thov__bottom">От влаги, ветра и плохого настроения. Зеленый - цвет весны и
                                    свежести...</p>
                            </div>
                            <div className="ftr__btn__hov">
                                <div className="cart__btn">
                                    <span>Подробнее...</span>
                                </div>
                            </div>
                        </div>
                        <div className="ftr__bottom">
                            <div className="ftr__name">
                                <Link to="./" onClick={() => this.setModalActive4(<p>233</p>)}>
                                    Шторовка Contra
                                    </Link>
                            </div>
                            <div className="ftr__lower">
          <span>
                        6000₽
                      </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="ftr__more__btn">
                    <Link to="/Catalog">СМОТРЕТЬ БОЛЬШЕ</Link>
                </div>
            </div>
            <div className="modal__bottom">
                <Modal active={modalActive1} setActive={setModalActive1}>
                    <img className="modal__img" src={modalimg1} alt=""/>
                    <h2 className="modal__price">8000₽</h2>
                    <p className="modal__subtitle">
                        Потертая стилизованная джинса на плотной зимней подкладке. Все размеры. Высокий ворот, стильный яркий карман.
                    </p>
                    <img className="modal__scale" src={scale} alt=""/>
                    <img className="modal__colors" src={colors} alt=""/>
                    <button className="btn"><Link to="/Catalog" className="btn__link">КАТАЛОг</Link></button>
                </Modal>
                <Modal active={modalActive2} setActive={setModalActive2}>
                    <img className="modal__img" src={modalimg2} alt=""/>
                    <h2 className="modal__price">6000₽</h2>
                    <p className="modal__subtitle">
                        От влаги, ветра и плохого настроения. Зеленый - цвет весны и свежести.
                    </p>
                    <img className="modal__scale" src={scale} alt=""/>
                    <img className="modal__colors" src={colors} alt=""/>
                    <button className="btn"><Link to="/Catalog" className="btn__link">КАТАЛОг</Link></button>

                </Modal>
                <Modal active={modalActive3} setActive={setModalActive3}>
                    <img className="modal__img" src={modalimg4} alt=""/>
                    <h2 className="modal__price">2600₽</h2>
                    <p className="modal__subtitle">
                        Дерзость и молодость. Прямой козырек, сочный принт. Летом защищает от солнца, зимой от снега.
                    </p>
                    <img className="modal__scale" src={scale} alt=""/>
                    <img className="modal__colors" src={colors} alt=""/>
                    <button className="btn"><Link to="/Catalog" className="btn__link">КАТАЛОг</Link></button>

                </Modal>
                <Modal active={modalActive4} setActive={setModalActive4}>
                    <img className="modal__img" src={modalimg3} alt=""/>
                    <h2 className="modal__price">6000₽</h2>
                    <p className="modal__subtitle">
                        Урбанистский стиль с солнечными нотами.
                    </p>
                    <img className="modal__scale" src={scale} alt=""/>
                    <img className="modal__colors" src={colors} alt=""/>
                    <button className="btn"><Link to="/Catalog" className="btn__link">КАТАЛОг</Link></button>

                </Modal>
            </div>
        </div>

    );
};

export default Actual;