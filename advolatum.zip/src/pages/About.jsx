import React from 'react';
import AboutUs from '../images/about.png'
import Galery from '../images/galery.svg'
import Geoposition from "../components/Geoposition/Geoposition";

const About = () => {
    return (
        <div id="information-information" className="">
            <div className="container__adv">
                <div className="">
                    <div id="content">
                        <div className="container__adv">
                            <div className="about__page">
                                <div className="about__header">
                                    <div className="ftr__header featured__top">
                                        <img src={AboutUs} alt=""/>
                                        <h3>О нас</h3>
                                    </div>
                                </div>
                                <div className="about__box">
                                    <div className="about__text">
                                        <p>Разнообразный и богатый опыт укрепление и развитие структуры в значительной степени обуславливает создание соответствующий условий активизации. С другой стороны начало повседневной работы по формированию позиции позволяет выполнять важные задания по разработке существенных финансовых и административных условий. Задача организации, в особенности же новая модель организационной деятельности требуют определения и уточнения систем массового участия. Не следует, однако забывать, что сложившаяся структура организации требуют определения и уточнения существенных финансовых и административных условий. Повседневная практика показывает, что дальнейшее развитие различных форм деятельности требуют определения и уточнения форм развития.</p>
                                    </div>
                                </div>
                            </div>
                            <div className="about__image">
                                <img src={Galery} alt=""/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <Geoposition/>
        </div>
    );
};

export default About;