import React, {useEffect, useState} from 'react';
import { Link } from "react-router-dom";
import Collection from "../images/Коллекции.png";
import Colors from "../images/Цвета.png"
import card1 from "../images/cardone.jpeg";
import axios from "axios";
const Catalog = () => {
    const [catalog, setCatalog] = useState([])

    useEffect(() => {
        axios('http://localhost:8888/products')
            .then(({ data }) => setCatalog(data))
    }, [])
    return (
        <div className="container__adv">
            <div id="content">
                <div className="Collection">
                    <img src={Collection} alt=""/>
                </div>
                    <div className="categories">
                        <li className="category"><Link to="/Catalog">Все товары</Link></li>
                        <li className="category"><Link to="/Catalog">Сумки</Link></li>
                        <li className="category"><Link to="/Catalog">Куртки</Link></li>
                        <li className="category"><Link to="/Catalog">Кофты</Link></li>
                        <li className="category"><Link to="/Catalog">Верхняя Одежда</Link></li>
                        <li className="category"><Link to="/Catalog">Аксессуары</Link></li>
                        <li className="category__img"><img src={Colors} alt=""/></li>
                    </div>
                <div className="cards">
                    <div className="ftr__items__wrap">
                        <div className="ftr__items__cards">
                            {catalog.map(item => (
                                <div className="product-layout ftr__item__box">
                                        <img className="product-layout ftr__item__box" src={item.images} alt=""/>
                                    <div className="ftr__image hov__point">
                                        <div className="ftr__text__hov">
                                            <Link to="/ca" className="thov__top">{item.title}</Link>
                                            <p className="thov__bottom">{item.subtitle}</p>
                                        </div>
                                        <div className="ftr__bottom">
                                            <div className="ftr__name">
                                                <Link to="./">{item.title}</Link>
                                            </div>
                                            <div className="ftr__lower">
                                                <span>{item.price}₽</span>
                                                <div className="cart__btn" >
                                                    <span>В корзину</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                            <div className="product-layout ftr__item__box" style={{ backgroundImage:`url(${card1})`,backgroundRepeat:"no-repeat", backgroundSize:"contain"}}>
                                <div className="ftr__image hov__point">
                                    <div className="ftr__text__hov">
                                        <p className="thov__top">Куртка Antiquus</p>
                                        <p className="thov__bottom">Потертая стилизованная джинса на плотной зимней подкладке.
                                            Все размеры. Высокий ворот, стильный ярки..</p>
                                    </div>
                                    <div  className="ftr__btn__hov">
                                        <div className="cart__btn">
                                            <span>Подробнее...</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="ftr__bottom">
                                    <div className="ftr__name">
                                        <Link to="./">Куртка Antiquus</Link>
                                    </div>
                                    <div className="ftr__lower">
                                <span>
                        8000₽
                      </span>
                                        <div className="cart__btn" >
                                            <span>В корзину</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Catalog;