import React from 'react';

import { Link } from "react-router-dom";

import image_one from '../images/one.jpeg'
import image_two from '../images/two.jpeg'
import image_three from '../images/three.jpeg'
import image_four from '../images/four.jpeg'
import Geoposition from "../components/Geoposition/Geoposition";

const Colection = () => {
    return (
        <div id="information-information" className="">
            <div className="container__adv">
                <div className="">
                    <div id="content">
                        <div id="product-category" className="category__page collections__page">
                            <div id="content" className="cat__items__box">
                                <div className="ftr__items__wrap">
                                    <div className="product-layout ftr__item__box">
                                        <Link to="/Catalogpage" className="ftr__image " style={{ backgroundImage:`url(${image_one})`,backgroundRepeat:"no-repeat"}}>

                                        </Link>
                                        <div className="ftr__bottom">
                                            <div className="ftr__name">
                                                <Link to="/Catalogpage">Классика</Link>
                                            </div>
                                        </div>
                                        <span className="v-view qu"
                                              data-url="#">
                                            <i className="fa fa-eye">
                                             Quick View
                                            </i>
                                        </span>
                                    </div>
                                    <div className="product-layout ftr__item__box">
                                        <Link to="/Catalogpagetwo" className="ftr__image " style={{ backgroundImage:`url(${image_two})`,backgroundRepeat:"no-repeat"}}>

                                        </Link>
                                        <div className="ftr__bottom">
                                            <div className="ftr__name">
                                                <Link to="/Catalogpagetwo">Flavum</Link>
                                            </div>
                                        </div>
                                        <span className="v-view qu"
                                              data-url="#"><i
                                            className="fa fa-eye">
                                            Quick View
                                        </i>

                                        </span>
                                    </div>
                                    <div className="product-layout ftr__item__box">
                                        <Link to="/Catalogpagethree" className="ftr__image " style={{ backgroundImage:`url(${image_three})`,backgroundRepeat:"no-repeat"}}>

                                        </Link>
                                        <div className="ftr__bottom">
                                            <div className="ftr__name">
                                                <Link to="/Catalogpagethree">Violaceum</Link>
                                            </div>
                                        </div>
                                        <span className="v-view qu"
                                              data-url="#"><i
                                            className="fa fa-eye">
                                           Quick View
                                        </i>
                                        </span>
                                    </div>
                                    <div className="product-layout ftr__item__box">
                                        <Link to="/Catalogpagefour" className="ftr__image " style={{ backgroundImage:`url(${image_four})`,backgroundRepeat:"no-repeat"}}>

                                        </Link>
                                        <div className="ftr__bottom">
                                            <div className="ftr__name">
                                                <Link to="/Catalogpagefour">Viridis</Link>
                                            </div>
                                        </div>
                                        <span className="v-view qu"
                                              data-url="#">
                                            <i className="fa fa-eye">
                                                Quick View
                                              </i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
};

export default Colection;