import React from 'react';
import classico from "../images/Классика.png";
import {Link} from "react-router-dom";
import Classico_two from "../images/z1.jpg";
import Classico_one from "../images/z2.jpg";
import draw from "../images/2022.svg";
import Classico_three from "../images/z3.jpg";
import actual from "../images/На этот сезон ДУБЛЬ.png";
import card1 from "../images/cardfour.jpeg";
import card2 from "../images/card7.jpeg";
import card4 from "../images/cardtwo.jpeg";
import Geoposition from "../components/Geoposition/Geoposition";


const Catalogpagefour = () => {
    return (
        <div className="container__adv">
            <div className="onecollection__page">
                <div className="collection__top">
                    <div className="container__adv">

                        <div className="collection__box">
                            <div className="coll__arrow">
                                <img src={classico} alt=""/>
                                <Link to="/Colection">Другие коллекции</Link>
                            </div>
                            <div className="coll__content">

                                <div className="coll__left">
                                    <div className="coll__topimg">
                                        <img src={Classico_two} alt="Classico One"/>
                                    </div>
                                    <div className="coll__midimg">
                                        <img src={Classico_one} alt="Classico Two"/>
                                    </div>
                                    <div className="coll__bottom">
                                        <p>Зеленая коллекция</p>
                                        <div className="coll__num">
                                            <img src={draw} alt="Collection Number"/>
                                        </div>
                                    </div>
                                </div>
                                <div className="coll__right">
                                    <div className="coll__bigpic">
                                        <img src={Classico_three} alt="Classico One"/>
                                    </div>
                                    <p className="coll__bottom__text">
                                        ЗЕЛЕНЫЙ - ЦВЕТ ОПТИМИЗМА И ВЕРЫ В СВЕТЛОЕ БУДУЩЕЕ НЕ СМОТРЯ НА БУДНИЧНУЮ СЕРОСТЬ.
                                    </p>
                                </div>
                            </div>
                            <div className="coll__arrow arrow__bottom">
                                <button className="btn">
                                    <Link to="/" className="btn__link">Смотреть</Link>
                                </button>
                                <Link to="/Colection">Другие коллекции</Link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container__adv">
                <div className="ftr__header featured__top">
                    <img src={actual} alt=""/>
                    <h2 className="actual__title">Актуальное</h2>
                </div>
                <div className="featured__box">
                    <div className="ftr__items__cards">
                        <div className="product-layout ftr__item__box" style={{ backgroundImage:`url(${card1})`,backgroundRepeat:"no-repeat", backgroundSize:"contain"}}>>
                            <div className="ftr__image hov__point">
                                <div className="ftr__text__hov">
                                    <p className="thov__top">Снэбпек Бошка</p>
                                    <p className="thov__bottom">Костюм оверсайз из микровелюра. Держит теплую воздушную подушку внутри костюма. Не сковывает движени..</p>
                                </div>
                                <div className="ftr__btn__hov">
                                    <div className="cart__btn">
                                        <span>Подробнее...</span>
                                    </div>
                                </div>
                            </div>
                            <div className="ftr__bottom">
                                <div className="ftr__name">
                                    <a href="#">Снэбпек Бошка</a>
                                </div>
                                <div className="ftr__lower">
                                <span>
                        2600₽
                      </span>
                                    <div className="cart__btn">
                                        <span>В корзину</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="product-layout ftr__item__box" style={{ backgroundImage:`url(${card2})`,backgroundRepeat:"no-repeat",backgroundSize:"contain"}}>>
                            <div className="ftr__image hov__point"
                            >
                                <div className="ftr__text__hov">
                                    <p className="thov__top">Кофта Still</p>
                                    <p className="thov__bottom">Урбанистский стиль с солнечными нотами.&nbsp;..</p>
                                </div>
                                <div className="ftr__btn__hov">
                                    <div className="cart__btn">
                                        <span>Подробнее...</span>
                                    </div>
                                </div>
                            </div>
                            <div className="ftr__bottom">
                                <div className="ftr__name">
                                    <a href="#">Штормовка Contra</a>
                                </div>
                                <div className="ftr__lower">
          <span>
                        6000₽
                      </span>
                                    <div className="cart__btn">
                                        <span>В корзину</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="product-layout ftr__item__box" style={{ backgroundImage:`url(${card4})`,backgroundRepeat:"no-repeat",backgroundSize:"contain"}}>>
                            <div className="ftr__image hov__point"
                            >
                                <div className="ftr__text__hov">
                                    <p className="thov__top">Снепбэк Бошка</p>
                                    <p className="thov__bottom">Дерзость и молодость. Прямой козырек, сочный принт. Летом
                                        защищает от солнца, зимой от снега...</p>
                                </div>
                                <div className="ftr__btn__hov">
                                    <div className="cart__btn">
                                        <span>Подробнее...</span>
                                    </div>
                                </div>
                            </div>
                            <div className="ftr__bottom">
                                <div className="ftr__name">
                                    <a href="#">Штормовка Contra</a>
                                </div>
                                <div className="ftr__lower">
          <span>
                        6000₽
                      </span>
                                    <div className="cart__btn">
                                        <span>В корзину</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="ftr__more__btn">
                        <a href="#">СМОТРЕТЬ БОЛЬШЕ</a>
                    </div>
                </div>
            </div>
            <Geoposition/>
        </div>
    );
};

export default Catalogpagefour;