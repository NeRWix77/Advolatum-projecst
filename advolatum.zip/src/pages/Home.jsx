import React, {useState} from 'react';
import Navbar from "../components/Navbar/Navbar";
import Season from "../components/Season/Season";
import Actual from "../components/Actual/Actual";
import Geoposition from "../components/Geoposition/Geoposition";



const Home = () => {
    return (
        <div>
            <Navbar/>
            <Season/>
            <Actual/>
            <Geoposition/>
        </div>

    );
};

export default Home;