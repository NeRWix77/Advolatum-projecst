import React from 'react';

import bgImage from '../images/Корзина.png'

const Basket = () => {
    return (
        <div>
            
        </div>
    );
};

export default Basket;